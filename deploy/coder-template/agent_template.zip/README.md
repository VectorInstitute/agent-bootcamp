---
display_name: Agentic AI Bootcamp
description: Provision Coder workspaces for the Vector Agentic AI Bootcamp
icon: ../../../site/static/icon/gcp.png
maintainer_github: coder
verified: true
tags: [vm, linux, gcp]
---

# Agentic AI Bootcamp

## Prerequisites

### Authentication

This template provides the software environment needed to run Vector Institute's Agentic AI Bootcamp.
